library(testthat)
library(StatAid)

test_check("StatAid")
